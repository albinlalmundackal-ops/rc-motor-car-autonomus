#define TRIG_FRONT 2
#define ECHO_FRONT 3

#define TRIG_LEFT 4
#define ECHO_LEFT 7

#define TRIG_RIGHT A2
#define ECHO_RIGHT A3

#define ENA 5
#define IN1 8
#define IN2 9
#define IN3 10
#define IN4 11
#define ENB 6

#define SPEED 180
#define LIMIT 20

float getDistance(int trigPin, int echoPin) {

  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);

  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);

  digitalWrite(trigPin, LOW);

  long duration = pulseIn(echoPin, HIGH, 30000);

  if (duration == 0) {
    return -1;
  }

  return duration * 0.0343 / 2;
}

// Move forward
void forward() {

  analogWrite(ENA, SPEED);
  analogWrite(ENB, SPEED);

  digitalWrite(IN1, HIGH);
  digitalWrite(IN2, LOW);

  digitalWrite(IN3, HIGH);
  digitalWrite(IN4, LOW);
}

// Move backward
void backward() {

  analogWrite(ENA, SPEED);
  analogWrite(ENB, SPEED);

  digitalWrite(IN1, LOW);
  digitalWrite(IN2, HIGH);

  digitalWrite(IN3, LOW);
  digitalWrite(IN4, HIGH);
}

// Turn left
void turnLeft() {

  analogWrite(ENA, SPEED);
  analogWrite(ENB, SPEED);

  digitalWrite(IN1, LOW);
  digitalWrite(IN2, HIGH);

  digitalWrite(IN3, HIGH);
  digitalWrite(IN4, LOW);
}

// Turn right
void turnRight() {

  analogWrite(ENA, SPEED);
  analogWrite(ENB, SPEED);

  digitalWrite(IN1, HIGH);
  digitalWrite(IN2, LOW);

  digitalWrite(IN3, LOW);
  digitalWrite(IN4, HIGH);
}

// Stop motors
void stopMotor() {

  analogWrite(ENA, 0);
  analogWrite(ENB, 0);

  digitalWrite(IN1, LOW);
  digitalWrite(IN2, LOW);

  digitalWrite(IN3, LOW);
  digitalWrite(IN4, LOW);
}

void setup() {

  Serial.begin(9600);

  pinMode(TRIG_FRONT, OUTPUT);
  pinMode(ECHO_FRONT, INPUT);

  pinMode(TRIG_LEFT, OUTPUT);
  pinMode(ECHO_LEFT, INPUT);

  pinMode(TRIG_RIGHT, OUTPUT);
  pinMode(ECHO_RIGHT, INPUT);

  pinMode(ENA, OUTPUT);
  pinMode(ENB, OUTPUT);

  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  pinMode(IN3, OUTPUT);
  pinMode(IN4, OUTPUT);

  stopMotor();
}

void loop() {

  float front = getDistance(TRIG_FRONT, ECHO_FRONT);
  delay(50);

  float left = getDistance(TRIG_LEFT, ECHO_LEFT);
  delay(50);

  float right = getDistance(TRIG_RIGHT, ECHO_RIGHT);

  Serial.print("Front: ");
  Serial.print(front);
  Serial.print(" cm | Left: ");
  Serial.print(left);
  Serial.print(" cm | Right: ");
  Serial.println(right);

  if (front < 0 || front > LIMIT) {

    Serial.println("Path Clear - Moving Forward");
    forward();

  }

  else {

    stopMotor();
    delay(300);

    Serial.println("Obstacle Detected");

    backward();
    delay(300);

    stopMotor();
    delay(200);

    // Treat missing side echo as open space
    float leftSpace = (left < 0) ? 999 : left;
    float rightSpace = (right < 0) ? 999 : right;

    if (leftSpace > rightSpace) {

      Serial.println("Turning Left");
      turnLeft();
      delay(400);

    }

    else {

      Serial.println("Turning Right");
      turnRight();
      delay(400);

    }

    stopMotor();
    delay(200);
  }
}